#include <stdio.h>
struct Student { int id; int score; };
int main(void)
{
    struct Student a = {2, 80};
    struct Student b = a;
    b.id = 5;
    printf("a=%d b=%d\n", a.id, b.id);
    return 0;
}
