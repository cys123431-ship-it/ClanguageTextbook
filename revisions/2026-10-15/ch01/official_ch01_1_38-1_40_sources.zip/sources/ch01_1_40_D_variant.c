#include <stdio.h>
typedef struct Flags {
    unsigned int active : 1;
    unsigned int level : 3;
} Flags;
int main(void)
{
    Flags f = {0, 7};
    printf("active=%u level=%u\n", (unsigned int)f.active, (unsigned int)f.level);
    return 0;
}
