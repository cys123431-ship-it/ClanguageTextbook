#include <stdio.h>
struct Student { int id; int score; };
void add_bonus(struct Student *s, int bonus)
{
    if (s != NULL) s->score += bonus;
}
int main(void)
{
    struct Student s = {8, 92};
    add_bonus(&s, 4);
    printf("id=%d score=%d\n", s.id, s.score);
    return 0;
}
