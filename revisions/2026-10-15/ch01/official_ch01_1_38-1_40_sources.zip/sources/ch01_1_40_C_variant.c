#include <stdio.h>
union Value { int number; double real; };
int main(void)
{
    union Value v;
    v.number = 30;
    printf("number=%d\n", v.number);
    v.real = 1.25;
    printf("real=%.2f\n", v.real);
    return 0;
}
