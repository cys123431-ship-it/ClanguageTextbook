#include <stdio.h>
struct Student { int id; int score; };
int main(void)
{
    struct Student s = {4, 70};
    s.score += 5;
    printf("id=%d score=%d\n", s.id, s.score);
    return 0;
}
