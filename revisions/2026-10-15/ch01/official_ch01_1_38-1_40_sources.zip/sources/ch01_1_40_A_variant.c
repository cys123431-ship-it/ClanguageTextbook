#include <stdio.h>
enum Stage { READY, RUNNING, DONE };
int main(void)
{
    enum Stage state = DONE;
    switch (state) {
        case READY: puts("ready"); break;
        case RUNNING: puts("running"); break;
        case DONE: puts("done"); break;
        default: puts("unknown"); break;
    }
    printf("code=%d\n", (int)state);
    return 0;
}
