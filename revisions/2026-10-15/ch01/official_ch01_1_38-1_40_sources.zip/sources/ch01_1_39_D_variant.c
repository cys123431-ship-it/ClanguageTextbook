#include <stdio.h>
#include <stddef.h>
struct Student { int id; int score; };
int main(void)
{
    struct Student a[] = {{1, 60}, {2, 40}, {3, 80}};
    size_t n = sizeof a / sizeof a[0];
    for (size_t i = 0; i < n; ++i) {
        size_t best = i;
        for (size_t j = i + 1; j < n; ++j) {
            if (a[j].score > a[best].score) best = j;
        }
        struct Student temp = a[i];
        a[i] = a[best];
        a[best] = temp;
    }
    for (size_t i = 0; i < n; ++i) {
        printf("%d:%d\n", a[i].id, a[i].score);
    }
    return 0;
}
