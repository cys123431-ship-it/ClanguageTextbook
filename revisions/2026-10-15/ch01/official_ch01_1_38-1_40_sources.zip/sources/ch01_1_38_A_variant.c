#include <stdio.h>
struct Student { int id; int score; };
int main(void)
{
    struct Student s = {9, 60};
    s.score += 12;
    printf("id=%d score=%d\n", s.id, s.score);
    return 0;
}
