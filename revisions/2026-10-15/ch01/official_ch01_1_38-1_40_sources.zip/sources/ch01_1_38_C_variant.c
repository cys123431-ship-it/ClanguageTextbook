#include <stdio.h>
struct Point { int x; int y; };
struct Marker { int id; struct Point position; };
int main(void)
{
    struct Marker m = {5, {1, 8}};
    m.position.y -= 3;
    printf("%d:(%d,%d)\n", m.id, m.position.x, m.position.y);
    return 0;
}
