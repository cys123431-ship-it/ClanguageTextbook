#include <stdio.h>
struct Student { int id; int score; };
void add_bonus(struct Student *s, int bonus)
{
    if (s != NULL) s->score += bonus;
}
int main(void)
{
    struct Student s = {8, 81};
    add_bonus(&s, 7);
    printf("id=%d score=%d\n", s.id, s.score);
    return 0;
}
