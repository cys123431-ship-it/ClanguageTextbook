#include <stdio.h>
struct Point { int x; int y; };
struct Marker { int id; struct Point position; };
int main(void)
{
    struct Marker m = {3, {4, 6}};
    m.position.x += 2;
    printf("%d:(%d,%d)\n", m.id, m.position.x, m.position.y);
    return 0;
}
