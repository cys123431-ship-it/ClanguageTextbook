#include <stdio.h>
#include <stddef.h>
struct Student { int id; int score; };
int main(void)
{
    struct Student a[] = {{11, 72}, {12, 91}, {13, 85}};
    size_t count = sizeof a / sizeof a[0];
    size_t best = 0;
    for (size_t i = 1; i < count; ++i) {
        if (a[i].score > a[best].score) best = i;
    }
    printf("best=%d score=%d\n", a[best].id, a[best].score);
    return 0;
}
