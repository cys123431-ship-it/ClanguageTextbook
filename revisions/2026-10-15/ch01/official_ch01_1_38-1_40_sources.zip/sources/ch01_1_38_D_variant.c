#include <stdio.h>
struct Sensor { int channel; int value; int valid; };
int main(void)
{
    struct Sensor s = {.value = 18, .valid = 0, .channel = 2};
    printf("ch=%d value=%d valid=%d\n", s.channel, s.value, s.valid);
    return 0;
}
