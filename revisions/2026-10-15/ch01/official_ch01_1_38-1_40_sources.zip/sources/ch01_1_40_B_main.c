#include <stdio.h>
enum Level { LOW = 2, MEDIUM, HIGH = 8 };
int main(void)
{
    printf("%d %d %d\n", LOW, MEDIUM, HIGH);
    return 0;
}
