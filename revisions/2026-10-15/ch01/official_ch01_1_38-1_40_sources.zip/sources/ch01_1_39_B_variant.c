#include <stdio.h>
struct Student { int id; int score; };
int raised(struct Student copy)
{
    copy.score += 20;
    return copy.score;
}
int main(void)
{
    struct Student original = {4, 70};
    int result = raised(original);
    printf("original=%d result=%d\n", original.score, result);
    return 0;
}
