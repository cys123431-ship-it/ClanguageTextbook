#include <stdio.h>
union Value { int number; double real; };
int main(void)
{
    union Value v;
    v.number = 12;
    printf("number=%d\n", v.number);
    v.real = 2.5;
    printf("real=%.1f\n", v.real);
    return 0;
}
