#include <stdio.h>
struct Sensor { int channel; int value; int valid; };
int main(void)
{
    struct Sensor s = {.valid = 1, .channel = 7, .value = 42};
    printf("ch=%d value=%d valid=%d\n", s.channel, s.value, s.valid);
    return 0;
}
