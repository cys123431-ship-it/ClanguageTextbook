#include <stdio.h>
struct Student { int id; int score; };
int main(void)
{
    struct Student a = {2, 80};
    struct Student b = {0, 0};
    b = a;
    b.score = 95;
    printf("a=%d b=%d\n", a.score, b.score);
    return 0;
}
