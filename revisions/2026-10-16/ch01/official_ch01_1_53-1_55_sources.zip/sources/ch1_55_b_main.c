#include <errno.h>
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    const char input[] = "999999999999999999999999999999999999999999999";
    char *end = NULL;
    errno = 0;
    (void)strtol(input, &end, 10);
    if (errno == ERANGE)
        puts("out of range");
    else if (end == input || *end != '\0')
        puts("invalid text");
    else
        puts("within range");
    return 0;
}
