#include <math.h>
#include <stdio.h>

int main(void)
{
    double root = sqrt(81.0);
    double distance = hypot(3.0, 4.0);
    printf("root=%.1f distance=%.1f\n", root, distance);
    return 0;
}
