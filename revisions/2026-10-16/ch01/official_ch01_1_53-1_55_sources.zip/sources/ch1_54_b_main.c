#include <stdio.h>
#include <time.h>

int main(void)
{
    struct tm t = {0};
    char text[16];
    t.tm_hour = 14;
    t.tm_min = 7;
    t.tm_sec = 5;
    if (strftime(text, sizeof text, "%H:%M:%S", &t) == 0)
        return 1;
    printf("clock=%s\n", text);
    return 0;
}
