#include <math.h>
#include <stdio.h>

int main(void)
{
    double power = pow(2.0, 5.0);
    double magnitude = fabs(-3.5);
    printf("power=%.1f magnitude=%.1f\n", power, magnitude);
    return 0;
}
