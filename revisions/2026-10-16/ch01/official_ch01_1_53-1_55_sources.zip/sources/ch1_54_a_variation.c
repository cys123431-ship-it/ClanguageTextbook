#include <stdio.h>
#include <time.h>

int main(void)
{
    struct tm date = {0};
    char buffer[32];
    date.tm_year = 2024 - 1900;
    date.tm_mon = 3 - 1;
    date.tm_mday = 1;
    if (strftime(buffer, sizeof buffer, "%Y-%m-%d", &date) == 0)
        return 1;
    puts(buffer);
    return 0;
}
