#include <math.h>
#include <stdio.h>

int main(void)
{
    double x = -3.2;
    printf("floor=%.0f ceil=%.0f trunc=%.0f\n",
           floor(x), ceil(x), trunc(x));
    return 0;
}
