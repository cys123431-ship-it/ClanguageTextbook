#include <stdio.h>
#include <time.h>

int main(void)
{
    struct tm a = {0};
    struct tm b = {0};
    a.tm_year = b.tm_year = 2026 - 1900;
    a.tm_mon = b.tm_mon = 10 - 1;
    a.tm_mday = b.tm_mday = 16;
    a.tm_hour = b.tm_hour = 12;
    b.tm_min = 2;
    b.tm_sec = 30;
    a.tm_isdst = b.tm_isdst = -1;
    time_t start = mktime(&a);
    time_t end = mktime(&b);
    if (start == (time_t)-1 || end == (time_t)-1)
        return 1;
    printf("elapsed=%.0f seconds\n", difftime(end, start));
    return 0;
}
