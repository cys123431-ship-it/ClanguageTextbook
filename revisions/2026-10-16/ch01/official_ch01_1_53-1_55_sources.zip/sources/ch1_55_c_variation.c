#include <assert.h>
#include <stddef.h>
#include <stdio.h>

int sum_positive(const int *data, size_t count)
{
    assert(data != NULL);
    assert(count > 0);
    int total = 0;
    for (size_t i = 0; i < count; ++i)
        total += data[i];
    return total;
}

int main(void)
{
    const int numbers[] = {2, 4, 6};
    int result = sum_positive(numbers, sizeof numbers / sizeof numbers[0]);
    printf("sum=%d\n", result);
    return 0;
}
