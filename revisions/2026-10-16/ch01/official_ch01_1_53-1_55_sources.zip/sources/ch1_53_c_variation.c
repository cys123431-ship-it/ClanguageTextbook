#include <math.h>
#include <stdio.h>

int main(void)
{
    double power = pow(3.0, 3.0);
    double magnitude = fabs(-4.25);
    printf("power=%.1f magnitude=%.2f\n", power, magnitude);
    return 0;
}
