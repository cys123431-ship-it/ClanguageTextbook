#include <math.h>
#include <stdio.h>

int main(void)
{
    double root = sqrt(49.0);
    double distance = hypot(5.0, 12.0);
    printf("root=%.1f distance=%.1f\n", root, distance);
    return 0;
}
