#include <stdio.h>
#include <time.h>

int main(void)
{
    struct tm t = {0};
    char text[16];
    t.tm_hour = 9;
    t.tm_min = 3;
    t.tm_sec = 12;
    if (strftime(text, sizeof text, "%H:%M:%S", &t) == 0)
        return 1;
    printf("clock=%s\n", text);
    return 0;
}
