#include <errno.h>
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    const char input[] = "120x";
    char *end = NULL;
    errno = 0;
    long value = strtol(input, &end, 10);
    if (end == input || *end != '\0' || errno == ERANGE)
        puts("invalid");
    else
        printf("value=%ld\n", value);
    return 0;
}
