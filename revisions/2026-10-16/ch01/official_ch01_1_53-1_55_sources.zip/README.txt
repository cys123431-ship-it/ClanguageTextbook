C11 독립 예제 9개 + 인접 변형 정답 9개. GCC/Clang: -std=c11 -Wall -Wextra -Wpedantic -Werror -O0 source.c -lm -o program
